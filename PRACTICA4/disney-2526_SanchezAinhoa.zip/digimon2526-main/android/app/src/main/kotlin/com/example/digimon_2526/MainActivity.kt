package com.example.digimon_2526

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
