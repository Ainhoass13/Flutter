package com.example.flutter_load_json

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
