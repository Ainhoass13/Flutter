package com.example.new_form

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
