package com.example.prova_2526

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
